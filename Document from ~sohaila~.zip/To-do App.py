
Python To-Do List Applicatio
todo_list = []

def add_todo():
    title = input("Enter the title of the To-Do: ")
    date = input("Enter the due date (e.g., 2025-10-01): ")
    todo = {"title": title, "date": date}
    todo_list.append(todo)
    print("To-Do added successfully!\n")

def view_todos():
    if not todo_list:
        print("To-Do list is empty.\n")
        return
    print("\nYour To-Do List:")
    for i, todo in enumerate(todo_list, start=1):
        print(f"{i}. {todo['title']} (Due: {todo['date']})")
    print()

def delete_todo():
    view_todos()
    if todo_list:
        try:
            index = int(input("Enter the number of the To-Do to delete: "))
            removed = todo_list.pop(index - 1)
            print(f"Deleted: {removed['title']}\n")
        except:
            print("Invalid input.\n")

def delete_all_todos():
    todo_list.clear()
    print("All To-Dos deleted!\n")

def main():
    while True:
        print("1. Add To-Do")
        print("2. View To-Dos")
        print("3. Delete a To-Do")
        print("4. Delete All To-Dos")
print("5. Exit")
        choice = input("Enter your choice (1-5): ")

        if choice == '1':
            add_todo()
        elif choice == '2':
            view_todos()
        elif choice == '3':
            delete_todo()
        elif choice == '4':
            delete_all_todos()
        elif choice == '5':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.\n")

main()

